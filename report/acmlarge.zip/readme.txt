ACM Transactions and Journals (Large Size) 
------------------------------------------------------------

The following files are available in the acmlarge.zip archive:

acmlarge.cls	     			- This is V1.4 of the LaTeX2e class file for the 'acmlarge template/format'
ACM-Reference-Format-Journals.bst	- This is the bibliography style file for the New ACM Reference Format (March 2012)
acmlarge-sample-bibfile.bib		- This is the bibliography database file
acmlarge-guide.pdf			- This is a PDF of the "author guidelines' for the acmlarge template
acm-update.pdf			        - This is a PDF of documentation updates
acmlarge-sample.pdf			- This is a PDF file showing what YOU should obtain
					  when YOU compile the sample source .tex file

acmlarge-sample.tex			- the revised (v2) source sample .tex file 
acmlarge-sample.bbl			- the bbl file as a result of 'BibTeX'ing 
acmlarge-mouse.eps			- Graphics file used in sample
acmlarge-mouse.pdf			- a graphics file in PDF format, (compatible with pdflatex)
readme.txt				- This file!

Happy (La)TeXing!!!


